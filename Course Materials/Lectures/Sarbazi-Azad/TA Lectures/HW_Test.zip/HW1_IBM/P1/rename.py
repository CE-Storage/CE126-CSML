import os
import shutil

def conv_num(n):
    s = ""
    for c in n:
        if c != ' ':
             s += str(int(c))
    return s

for dir in os.listdir('submissions'):
    if dir != conv_num(dir):
        shutil.move('submissions/' + dir, 'submissions/' + conv_num(dir))
