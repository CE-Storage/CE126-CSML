import os
import pandas as pd

df = pd.read_csv('../scores.csv', index_col=0)
df.fillna(0, inplace=True)

for dir in os.listdir('out'):
    score = 0
    correct = 0
    total = 0
    for i in os.listdir('tests'):
        if i.split('.')[1] == 'in':            
            o = i.split('.')[0] + '.out'
            f = open('tests/' + o)
            lines = []
            for l in f:
                lines.append(l.strip())
            try:  
                f = open("out/"+dir+"/"+i.split('.')[0]+".out")
                idx = 0
                for l in f:
                    try:
                        v = l.strip()
                        if lines[idx] == v:
                            correct += 1

                    except:
                        pass
                    idx += 1
                    total += 1
                
                if idx < len(lines):
                    total += len(lines) - idx
            except:
                total += len(lines)

    score = correct / total
    df.loc[int(dir), 'p1_test_score'] = score
    df.loc[int(dir), 'p1_score'] = score * (df.loc[int(dir), 'p1_late_factor'] / 100)
    print(score, dir)

df.to_csv('../scores.csv')
