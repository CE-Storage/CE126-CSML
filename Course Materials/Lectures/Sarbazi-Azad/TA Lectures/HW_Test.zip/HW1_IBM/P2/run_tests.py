import os
import shutil
import pandas as pd

def conv_num(n):
    s = ""
    for c in n:

        if c != ' ':
             s += str(int(c))
    return s

df = pd.read_csv('../scores.csv', index_col=0)
df.fillna(0, inplace=True)

for dir in os.listdir('submissions'):
    try:
        os.remove('submissions/' + dir + '/result.txt')
    except:
        pass
    try:
        os.remove('submissions/' + dir + '/driver.c')
        os.remove('submissions/' + dir + '/asm_io.o')
    except:
        pass
    progname = os.listdir('submissions/' + dir)
    progname = [x for x in progname if x.endswith('.asm') or x.endswith('.s') or x.endswith('.S') or x.endswith('.txt')]
    progname = progname[0]

    shutil.copy('template/asm_io.o', 'submissions/' + dir + '/')
    shutil.copy('template/driver.c', 'submissions/' + dir + '/')

    if (progname.split('.')[1] != 's'):
        shutil.move('submissions/' + dir + '/' + progname, 'submissions/' + dir + '/' + progname.split('.')[0] + '.s')
        progname = progname.split('.')[0] + '.s'

    result = os.system("cd submissions/" + dir + " && \
                        (s390x-linux-gnu-as -o object.o '" + progname + "' >/dev/null 2>/dev/null && s390x-linux-gnu-gcc -static -m64 -fno-pie -no-pie -std=c17 -o exec.out driver.c object.o asm_io.o >/dev/null 2>/dev/null)")
    
    score = 0
    if result == 0:
        correct = 0
        total = 0
        for i in os.listdir('tests'):
            if i.split('.')[1] == 'in':
                error = False
                exec_result = os.system("timeout 5s qemu-s390x ./submissions/" + dir + "/exec.out <tests/" + i + " >out.txt 2>/dev/null")
                
                if exec_result == 0:
                    o = i.split('.')[0] + '.out'
                    f = open('tests/' + o)
                    lines = []
                    for l in f:
                        lines.append(l.strip())
                    
                    f = open('out.txt')
                    idx = 0
                    for l in f:
                        try:
                            v = l.strip()
                            if lines[idx] != v:
                                error = True
                        except:
                            error = True
                        if len(v) > 0:
                            idx += 1

                    while idx < len(lines):
                        if len(lines[idx].strip()) == 0:
                            idx += 1
                        else:
                            break

                if not error and idx == len(lines):
                    correct += 1

                total += 1

        score = correct / total
        df.loc[int(dir), 'p2_test_score'] = score
    df.loc[int(dir), 'p2_score'] = score * (df.loc[int(dir), 'p2_late_factor'] / 100)
    print(score, dir)

df.to_csv('../scores.csv')
