import os
import shutil

for dir in os.listdir('submissions'):
    try:
        os.remove('submissions/' + dir + '/result.txt')
    except:
        pass
    try:
        os.remove('submissions/' + dir + '/driver.c')
    except:
        pass
    progname = os.listdir('submissions/' + dir)
    progname = [x for x in progname if x.endswith('.asm') or x.endswith('.s') or x.endswith('.S') or x.endswith('.txt')]
    progname = progname[0]

    shutil.copy('template/driver.c', 'submissions/' + dir + '/')

    if (progname.split('.')[1] != 's'):
        shutil.move('submissions/' + dir + '/' + progname, 'submissions/' + dir + '/' + progname.split('.')[0] + '.s')
        progname = progname.split('.')[0] + '.s'

    result = os.system("cd submissions/" + dir + " && \
                        (as -o object.o '" + progname + "' >/dev/null 2>/dev/null && gcc -m64 -no-pie -std=c17 -o exec.out driver.c object.o >/dev/null 2>/dev/null)")

    if result == 0:
        os.makedirs('out/' + dir, exist_ok=True)
        for i in os.listdir('tests'):
            if i.split('.')[1] == 'in':
                exec_result = os.system("timeout 15s ./submissions/" + dir + "/exec.out <tests/" + i + " >out/" + dir + "/" + i.split('.')[0] + ".out 2>/dev/null")
                if exec_result != 0:
                    os.system("echo 'RTE' >out/" + dir + "/" + i.split('.')[0] + ".out")
    print(dir)
