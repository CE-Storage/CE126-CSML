import os
import shutil
import pandas as pd

def conv_num(n):
    s = ""
    for c in n:

        if c != ' ':
             s += str(int(c))
    return s

d = {'student_id': [], 'p1': [], 'p2': [], 'p3': [], 'p4': []}
for dir in os.listdir('submissions'):
    d['student_id'].append(dir)
    d['p1'].append(0.0)
    d['p2'].append(0.0)
    d['p3'].append(0.0)
    d['p4'].append(0.0)

df = pd.DataFrame(d)
df.to_csv('scores.csv', index=False)