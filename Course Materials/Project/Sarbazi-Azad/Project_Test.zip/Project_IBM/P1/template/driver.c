void asm_main();

int main() {
  asm_main();
  
  return 0;
}

