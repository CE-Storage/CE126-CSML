import os
import pandas as pd

primes = [2]
for i in range(3, 1000):
    p = True
    for j in range(len(primes)):
        if i % primes[j] == 0:
            p = False
            break
    if p:
        primes.append(i)


def is_prime(n):
    j = 0
    while primes[j] < n:
        j += 1
    return primes[j] == n


df = pd.read_csv('../scores.csv', index_col=0)
df.fillna(0, inplace=True)

for dir in os.listdir('out'):
    score = 0
    correct = 0
    total = 0
    for i in os.listdir('tests'):
        if i.split('.')[1] == 'in':
            tf = open('tests/' + i, 'r')
            max_n = int(tf.readline().strip())
            if max_n % 2 == 1:
                max_n -= 1
            tf.close()

            total = (max_n - 2) // 2

            try: 
                f = open("out/"+dir+"/"+i.split('.')[0]+".out")
                p = 0
                idx = 0
                step = 2
                v = f.readline()
                if (len(v.strip()) > 0 and int(v.strip().split(' ')[0]) == 4):
                    idx = 4
                    step = 2
                else:
                    idx = max_n
                    step = -2
                f.close()

                f = open("out/"+dir+"/"+i.split('.')[0]+".out")
                for l in f:
                    try:
                        v = l.strip()
                        n, p1, p2 = l.split(' ')
                        n = int(n)
                        p1 = int(p1)
                        p2 = int(p2)

                        if (n == idx and is_prime(p1) and is_prime(p2) and p1 + p2 == n):
                            correct += 1
                    except:
                        pass
                    idx += step
            except:
                pass

    score = correct / total
    df.loc[int(dir), 'p3_test_score'] = score
    df.loc[int(dir), 'p3_score'] = score * (df.loc[int(dir), 'p3_late_factor'] / 100)
    print(score, dir)

df.to_csv('../scores.csv')
