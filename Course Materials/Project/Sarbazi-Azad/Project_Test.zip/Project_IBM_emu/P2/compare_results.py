import os
import pandas as pd

df = pd.read_csv('../scores.csv', index_col=0)
df.fillna(0, inplace=True)

for dir in os.listdir('out'):
    score = 0
    correct = 0
    total = 0
    for i in os.listdir('tests'):
        if i.split('.')[1] == 'in':     
            error = False       
            o = i.split('.')[0] + '.out'
            f = open('tests/' + o)
            lines = []
            for l in f:
                lines.append(l.strip())
            try:  
                f = open("out/"+dir+"/"+i.split('.')[0]+".out")
                solution = []
                for l in f:
                    solution.append(l.strip())

                if len(solution) != len(lines):
                    error = True
                else:
                    l = lines[0]
                    s = solution[0]
                    if l == "Impossible":
                        if s != l:
                            error = False
                    else:
                        l = l.split(' ')
                        s = s.split(' ')
                        if len(l) != len(s):
                            error = True
                        else:
                            idx = 0
                            for idx in range(len(s)):
                                a = float(l[idx])
                                b = float(s[idx])
                                diff = abs(a - b)
                                if diff / a > 0.05:
                                    error = True
                                    break
            except:
                error = True

            if not error:
                correct += 1
            
            total += 1

    score = correct / total
    df.loc[int(dir), 'p2_score'] = score
    print(score, dir)

df.to_csv('../scores.csv')
