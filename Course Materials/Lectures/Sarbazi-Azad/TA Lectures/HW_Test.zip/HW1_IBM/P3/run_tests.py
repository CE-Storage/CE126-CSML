import os
import shutil
import pandas as pd

def conv_num(n):
    s = ""
    for c in n:

        if c != ' ':
             s += str(int(c))
    return s

primes = [2]
for i in range(3, 1000):
    p = True
    for j in range(len(primes)):
        if i % primes[j] == 0:
            p = False
            break
    if p:
        primes.append(i)


def is_prime(n):
    j = 0
    while primes[j] < n:
        j += 1
    return primes[j] == n


df = pd.read_csv('../scores.csv', index_col=0)
df.fillna(0, inplace=True)

for dir in os.listdir('submissions'):
    try:
        os.remove('submissions/' + dir + '/result.txt')
    except:
        pass
    try:
        os.remove('submissions/' + dir + '/driver.c')
        os.remove('submissions/' + dir + '/asm_io.o')
    except:
        pass
    progname = os.listdir('submissions/' + dir)
    progname = [x for x in progname if x.endswith('.asm') or x.endswith('.s') or x.endswith('.S') or x.endswith('.txt')]
    progname = progname[0]

    shutil.copy('template/asm_io.o', 'submissions/' + dir + '/')
    shutil.copy('template/driver.c', 'submissions/' + dir + '/')

    if (progname.split('.')[1] != 's'):
        shutil.move('submissions/' + dir + '/' + progname, 'submissions/' + dir + '/' + progname.split('.')[0] + '.s')
        progname = progname.split('.')[0] + '.s'

    result = os.system("cd submissions/" + dir + " && \
                        (s390x-linux-gnu-as -o object.o '" + progname + "' >/dev/null 2>/dev/null && s390x-linux-gnu-gcc -static -m64 -fno-pie -no-pie -std=c17 -o exec.out driver.c object.o asm_io.o >/dev/null 2>/dev/null)")
    
    score = 0
    if result == 0:
        correct = 0
        total = 1
        i = '1.in'
        exec_result = os.system("timeout 15s qemu-s390x ./submissions/" + dir + "/exec.out <tests/" + i + " >out.txt 2>/dev/null")
        
        if exec_result == 0:
            f = open('out.txt', 'r')

            tf = open('tests/1.in', 'r')
            max_n = int(tf.readline().strip())
            if max_n % 2 == 1:
                max_n -= 1
            tf.close()

            total = (max_n - 2) // 2
                
            p = 0
            idx = 0
            step = 2
            v = f.readline()
            if (len(v.strip()) > 0 and int(v.strip().split(' ')[0]) == 4):
                idx = 4
                step = 2
            else:
                idx = max_n
                step = -2

            f = open('out.txt', 'r')
            for l in f:
                try:
                    v = l.strip()
                    n, p1, p2 = l.split(' ')
                    n = int(n)
                    p1 = int(p1)
                    p2 = int(p2)

                    if (n == idx and is_prime(p1) and is_prime(p2) and p1 + p2 == n):
                        correct += 1
                except:
                    pass

                idx += step

        score = correct / total
    df.loc[int(dir), 'p3_test_score'] = score
    df.loc[int(dir), 'p3_score'] = score * (df.loc[int(dir), 'p3_late_factor'] / 100)
    print(score, dir)

df.to_csv('../scores.csv')
