c = input()
while c != 'q':
    a = int(input())
    b = int(input())

    if c == '+':
        print(a + b)
    elif c == '-':
        print(a - b)
    elif c == '*':
        print(a * b)
    elif c == '/':
        print(a // b)
    elif c == '%':
        print(a % b)

    c = input()
